from django.apps import AppConfig


class PerevalAppConfig(AppConfig):
    name = 'pereval_app'
